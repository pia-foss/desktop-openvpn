
# Windows 10 EWDK (can just be ISO mount point)
EWDK = "C:\\WinWDK\\16299"

NSIS = "C:\\Program Files (x86)\\NSIS"
